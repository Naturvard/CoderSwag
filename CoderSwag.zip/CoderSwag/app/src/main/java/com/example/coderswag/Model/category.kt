package com.example.coderswag.Model

class category (val title:String ,val image:String){
    override fun toString(): String {
        return title
    }
}
