package com.example.coderswag.Model

class product(val title:String,val price:String,val image:String)